#!/bin/bash
watch -n 1 'adb shell b2g-procrank'
