# Boot to Gecko (B2G)

Boot to Gecko aims to create a complete, standalone operating system for the open web.

You can read more about B2G here:

  http://wiki.mozilla.org/B2G
  https://developer.mozilla.org/en-US/docs/Mozilla/B2G_OS

follow us on twitter: @Boot2Gecko

  http://twitter.com/Boot2Gecko

join the Mozilla Platform mailing list:

  http://groups.google.com/group/mozilla.dev.platform

and talk to us on IRC:

  #B2G on irc.mozilla.org

or Telegram:

  https://telegram.me/B2GOS

Discuss with Developers:

  Discourse: https://discourse.mozilla-community.org/c/b2g-os-participation
